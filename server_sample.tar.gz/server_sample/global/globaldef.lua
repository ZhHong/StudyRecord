local skynet = require "skynet"

NODE_NAME = skynet.getenv("nodename") or "noname"
