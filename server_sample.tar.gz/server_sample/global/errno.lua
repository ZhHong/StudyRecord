ErrorCode = {
	E_SUCCESS					= 0,		-- 成功
	E_ROLE_EXISTS				= 1,		-- 玩家角色已存在
	E_DB_ERROR					= 2,		-- 数据库操作失败
	E_ROLE_NOT_EXISTS			= 3,		-- 玩家角色不存在
}
