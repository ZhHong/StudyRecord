./tools/startlogin.sh
