-- create table
CREATE TABLE IF NOT EXISTS `user_info`(
	`uid` int(11) NOT NULL AUTO_INCREMENT,
	`uname` varchar(50) NOT NULL,
	`upass` varchar(50) NOT NULL,
	`reg_time` int(11),
	PRIMARY KEY(uid)
) ENGINE= InnoDB AUTO_INCREMENT =10000 DEFAULT CHARSET = UTF8;
//
--  update
DROP PROCEDURE IF EXISTS server_update;
CREATE PROCEDURE server_update()
BEGIN
	DECLARE uDbName varchar(128);
	select database() into uDbName;
	SET @result = 0;
	IF NOT EXISTS (select * from information_schema.columns where table_schema = uDbName and table_name = 'user_info' and column_name = 'login_time') THEN
		ALTER TABLE `user_info` ADD COLUMN  `login_time` int(11) DEFAULT 0 AFTER `reg_time`;
	END IF;
	SET @result = 1;
END;
CALL server_update();
DROP PROCEDURE IF EXISTS server_update;
//

-- proc
DROP PROCEDURE IF EXISTS get_user_info;
CREATE PROCEDURE get_user_info(IN in_uid int(11))
BEGIN
	SET @result =0;
	SELECT uname,upass,reg_time,login_time FROM user_info WHERE uid = in_uid;
	SET @result =1;
END;
//